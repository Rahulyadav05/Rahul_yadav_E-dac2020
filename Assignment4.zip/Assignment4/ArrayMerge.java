package Assignment4;

public class ArrayMerge {

	public static void main(String[] args) {

		int arr[]= {23,60,94,3,102};
		int arr1[]= {42,16,74};
		int alength= arr.length;
		int blength= arr1.length;
		
		int result[]= new int[alength+blength];
		int j=0,k=0,l=0;
		while(j<alength && k<blength)
		{
			result[l++] = arr[j++];
			result[l++] = arr1[k++];
		}
		
		  while(j<alength) 
		  { 
			  result[l++] = arr[j++];
		  }
		  
		   while(j<blength)
		   { 
			   result[l++] = arr1[k++]; 
		   }
		 
		for(int i=0;i<alength+blength;i++)
		{
		System.out.println(result[i]);
		}
	}

}
