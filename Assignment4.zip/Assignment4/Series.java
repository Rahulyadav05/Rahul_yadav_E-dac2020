package Assignment4;

import java.util.Scanner;
public class Series {

	public static void main(String[] args) 
	{  
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of elements in array");
		int n=sc.nextInt();
	int	temp=n;
	 for(int i=1;i<=n;i++)
	 {
		 if(temp%2==0)
		 {
			 temp=i*i;
			 System.out.print(temp+" ");
		 }
		 else
		 {
			 temp=i*i*i;
			 System.out.print(temp+" ");
		 }
	 }
	 
	


}
}