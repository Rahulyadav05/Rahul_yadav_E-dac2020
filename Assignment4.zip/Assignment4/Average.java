package Assignment4;

public class Average {

		public static void main(String[] args) {
			int[]a= {5,14,35,89,140};
			int sum=0;
			int l=a.length;
			for(int i=0;i<l-2;i++)
			{
				sum=sum+a[i];
			
			
			}
			int avg=sum/3;
			System.out.print(avg+" ");
			/*
			 * int y=a.length-1; int su=0; for(int j=1;j<y;j++) { su=su+a[j]; } int av=su/3;
			 * System.out.print(av);
			 */
		}

	}