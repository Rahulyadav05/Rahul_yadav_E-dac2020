package Array;

import java.util.Scanner;

public class ArrayDemo {
	
	static void display(int arr[]){
	    // Code for Traversal
	    for (int i = 0; i < arr.length; i++)
	    {
	        System.out.println(arr[i]);
	    }
	    System.out.println();
	}

	static int indInsertion(int arr[], int size, int element, int capacity, int index){
	    // code for Insertion
	    if(size>=capacity){
	        return -1;
	    }
	    for (int i = size-1; i >=index; i--)
	    {
	        arr[i+1] = arr[i];
	    }
	    arr[index] = element;
	    return 1; 
	}


	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of array ");
		int a = sc.nextInt();
		int arr[] = new int[a];
		
		for(int i=0;i<arr.length; i++)
		{
			arr[i] = sc.nextInt();
		}
	    int size = 5, element = 45, index=1;
	    display(arr); 
	    indInsertion(arr, size, element, 100, index);
	    size +=1;
	    display(arr);

	}

}


/*

class Searchval{

public static void main(String[] args) {
	int []arr= {1,5,8,9,10};
	int a=10;
	for (int i=0;i<arr.length;i++)
	{
		if (arr[i]==a)
		{
			System.out.print("integer found");
			break;
		}
		else
		{
			System.out.print("integer not found");
		}
		

}

}
}
public class Delete {

public static void main(String[] args) {

	int []arr= {45,67,56,43,23,45,67};
	int del=56;
	for(int i=0;i<arr.length-1;i++)
	{ 
		for(int j=i;j<arr.length-1;j++)
	{
		if(arr[i]==del)
		{
		arr[j]=arr[j+1];
		break;
	
	}
		
	}
		
}

	for(int i=0;i<arr.length-1;i++) {
        System.out.println(arr[i]);
}
		
}			
		
}

*/