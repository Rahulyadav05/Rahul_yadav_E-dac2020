package Array;

public class DeleteElement {

	public static void main(String[] args) {

		int[] arr = { 45, 67, 56, 43, 23, 45, 67 };
		int del = 56;
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = i; j < arr.length - 1; j++) {
				if (arr[i] == del) {
					arr[j] = arr[j + 1];
					break;

				}

			}

		}

		for (int i = 0; i < arr.length - 1; i++) {
			System.out.println(arr[i]);
		}

	}
}
