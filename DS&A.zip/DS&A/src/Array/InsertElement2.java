package Array;

public class InsertElement2 {

	public static void main(String[] args) {
		int arr[] = { 10, 45, 36, 78, 65, 33, 56, 78 };
		int indexpos = 3;
		int ele = 100;
		for (int i = arr.length - 1; i > indexpos - 1; i--) {
			arr[i] = arr[i - 1];
		}
		arr[indexpos - 1] = ele;

		for (int i = 0; i < arr.length - 1; i++) {
			System.out.println(arr[i]);
		}

	}
}