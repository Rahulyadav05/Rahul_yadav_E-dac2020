package Linkedlist;

public class DoublelyLinkedDemo {

	private Node2 start;
	private int length;
	
	DoublelyLinkedDemo()
	{
		this.start = null;
		this.length = 0;
	}

	public void insertBeg(int data)
	{
		Node2 newNode = new Node2(data);
		
		if(start == null)
		{
			start = newNode;
		}
		else {
			start.preLink = newNode;
			newNode.nextLink = start;
			start = newNode;
		}
		length++;
	}
	
	public void insertEnd(int data)
	{
		Node2 newNode = new Node2(data);
		
		if(start == null)
		{
			start = newNode;
		}
		else {
			Node2 n = start;
			
			while(n.nextLink != null)
			{
				n = n.nextLink;
			}
			n.nextLink = newNode;
			newNode.preLink = n;
		}
		length++;
	}
	
	public void insertAtPos(int data, int pos)
	{		
		if(pos == 1)
		{
			 insertBeg(data);
		}
		else if(pos>length)
		{
			insertEnd(data);
		}
		else {
			int i = 1;
			Node2 n = start;
			
			while(n.nextLink != null)
			{
				i++;
				if(i == pos)
				{
					break;
				}
				n = n.nextLink;
			}
			Node2 newNode = new Node2(data);
			newNode.preLink = n;
			newNode.nextLink = n.nextLink;
			n.nextLink.preLink = newNode;
			n.nextLink = newNode;
			
			length++;
		}
	}

	public void deleteBeg()
	{
		Node2 n = start;
		if(start == null)
		{
			System.out.println("List is Empty");
		}
		else {
			try
			{
			start = n.nextLink;
			start.preLink =null;
			}
			catch(Exception e)
			{
				
			}
			System.out.println(n.data + "Deleted element");
		}
		length--;
	}
	
	public void deletePos(int pos )
	{
	if(pos < 0)
	{
		System.out.println("Pos does not");
	    return;
	}
	if(pos==1)
	{
		deleteBeg();
	}
	else if(pos>length)
	{
		deleteEnd();
	}
	else
	{
		int i=1;
		Node2 p = start;
		
		while(p.nextLink!=null)
		{
			i++;
			if(i==pos)
			{
				break;
			}
			p=p.nextLink;
		}
		p.nextLink.nextLink.preLink = p;
		p.nextLink = p.nextLink.nextLink;
		length--;
	}
}
	
	public void deleteEnd()
	{
		if(start == null)
		{
			System.out.println("List is Empty");
		}
		else {
			Node2 n = start;
			
			while(n.nextLink.nextLink != null)
			{
				n = n.nextLink;
			}
			n.nextLink.preLink = null;
			n.nextLink = null;
			length++;
		}
	}
	
	public void displayForward() {
		Node2 n = start;
		while (n.nextLink != null) {
			System.out.print(n.data + " -->");
			n = n.nextLink;
		}
		System.out.println(n.data + " ");

	}
	
	public void displayBackward() {
		Node2 n = start;
		while (n.nextLink != null) {
			n = n.nextLink;
		}
		while (n.preLink != null) {
			System.out.print(n.data + " <- ");
			n = n.preLink;
		}
		System.out.print(n.data + " ");
	}

	public static void main(String[] args) {

		DoublelyLinkedDemo d1 = new DoublelyLinkedDemo();
		
		d1.insertBeg(10);
		d1.insertBeg(20);
		d1.insertBeg(30);
		d1.insertEnd(40);
		d1.insertAtPos(25, 4);
		d1.displayForward();
		
		d1.deleteEnd();
		d1.deleteBeg();
		
		d1.displayForward();
		
		System.out.println();
		d1.displayBackward();
		
	}

}
