package Linkedlist;

public class Node1 {

	int data;
	Node1 next;
}
