package Linkedlist;

public class LinkedListDemo {

	Node1 head;
	
	 void insert(int data)
	    {
	        Node1 node1=new Node1();
	        node1.data=data;
	        node1.next=null;
	        if(head==null)
	        {
	            head=node1;
	        }
	        else
	        {
	            Node1 n=head;
	            while(n.next!=null)
	            {
	              n=n.next;  
	            }
	            n.next=node1;
	        }
	    }
	
	public void insertEnd(int data)
	{
		Node1 node1 = new Node1();
		node1.data = data;
		node1.next = null; 
		
		if(head==null)
		{
			head = node1;
		}
		else
		{
			Node1 n = head;
			while(n.next!=null)
			{
				n = n.next;
			}
			n.next = node1;
		}
	}
	
	public void insertAtStart(int data)
	{
		Node1 node1 = new Node1();
		node1.data = data;
		node1.next = head;
		head = node1;
	}
	
	public void insertAt(int index , int data)
	{
		Node1 node1 = new Node1();
		node1.data = data;
		node1.next = head;
		
		if(index==0)
		{
			insertAtStart(data);
		}
		else {
		Node1 n = head;
		for(int i=0;i<index-1;i++)
		{
			n = n.next;
		}
		node1.next = n.next;
		n.next = node1;
		}
	}
	
	void deleteBeg()
	{
		if(head == null)
		{
			System.out.println("LinkedList is Empty");
		}
		else
		{
			int x;
			x = head.data;
			head = head.next;
			System.out.println(x+" Element Deleted Successfully");
		}
	}
	
	void deleteEnd()
	{
		Node1 n = head;
		if(head == null)
		{
			System.out.println("LinkedList is Empty");
		}
		while(n.next.next!=null)
		{
			n=n.next;
		}
		n.next = null;
	}
	
	public void deleteAt(int index)
	{
		if(index==0)
		{
			head = head.next;
		}
		else
		{
			Node1 n = head;
			Node1 n1 = null;
			for(int i=0;i<index-1;i++)
			{
				n = n.next;
			}
			n1 = n.next;
			n.next = n1.next;
			n1 = null;
		}
	}
	
	
	
	public void show()
	{
		Node1 node1 = head;
		
		while(node1.next!=null)
		{
			System.out.println(node1.data);
			node1 = node1.next;
		}
		System.out.println(node1.data);
	}
	
	public static void main(String[] args) {

		LinkedListDemo list = new LinkedListDemo();
		list.insertEnd(18);
		list.insertEnd(45);
		list.insertEnd(12);
		
		list.insertAtStart(25);
		list.insertAt(0, 55);
		
		//list.deleteAt(0);
		list.deleteEnd();
		list.show();
	}

}
