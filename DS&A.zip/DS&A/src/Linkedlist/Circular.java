package Linkedlist;

class Circular {
	

	private int[] arr;
	private int front, rear;
	
 
    public Circular(int k) {
    	this.arr = new int[k];
    	this.front = -1;
    	this.rear = 0;
    }
    

    public boolean enQueue(int value) {
        if (isFull()) return false;
    	arr[rear] = value;
        if (front == -1) front = rear;
        rear = (rear + 1)%arr.length;
        return true;
    }
    
   
    public boolean deQueue() {
        if (isEmpty()) return false;
        int val = arr[front];
              front = (front+1)%arr.length;
        if (front == rear) front = -1;

        return true;
       
    }
    

    public int Front() {
        if (isEmpty()) return -1;
        return arr[front];
    }
    

    public int Rear() {
        if (isEmpty()) return -1;
        return arr[(rear-1+arr.length)%arr.length];
    }
    

    public boolean isEmpty() {
        return (front == -1);
    }
    

    public boolean isFull() {
        return (front == rear);
    }

public static void main(String[] args)
{
	Circular cq=new Circular(5);
	cq.enQueue(45);
	cq.enQueue(56);

	
}
}