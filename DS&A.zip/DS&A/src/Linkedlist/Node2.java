package Linkedlist;

public class Node2 {

	int data;
	Node2 nextLink;
	Node2 preLink;
	
	Node2(int data)
	{
		this.data = data;
		this.nextLink = this.preLink = null;
	}
}
