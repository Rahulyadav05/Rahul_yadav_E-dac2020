package Linkedlist;

import java.util.Scanner;
class Node
{
	private int data;
	private Node next;
	public Node()
	{
		data=0;
		next=null;
	}
	public Node(int d,Node n)
	{
		data=d;
		next=n;
	}
	public void setData(int d)
	{
		data=d;
	}
	public void setNext(Node n)
	{
		next = n;
	}
	public int getData()
	{
		return data;
	}
	public Node getNext()
	{
		return next;
	}
}
 class LinkedList  
 {
	 private int size;
	 private Node start;
	 public LinkedList()
	 {
		 size=0;
		 start=null;
	 }
	 public boolean isEmpty()
	 {
		 if(start==null)
		 {
			 return true;
		 }
		 else
		 {
			 return false;
		 }
	 }
	 public int getSize()
	 {
		 return size;
	 }
	 public void view()
	 { 
		 Node t=start;
		 if(isEmpty())
		 {
			 System.out.println("List is Empty");
		 }
		 else
		 {
			 for(int i=1;i<=size;i++)
			 {
				 System.out.print(t.getData()+" ");
				 t=t.getNext();
			 }
		 }
	 }
	 public void insertAtFirst(int val)
	 {
		
		 Node n=new Node();
		 n.setData(val);
		 n.setNext(start);
		 start = n;
		 size++;
	 }
	 public void insertAtLast(int val)
	 {
		 Node n,t;
		 n=new Node();
		 n.setData(val);
		 t=start;
		 if(t== null)
		 {
			 start = n;
		 }
		 else
		 {
			 while(t.getNext()!=null)
			 {
				 t=t.getNext();
				 t.setNext(n);
				 size++;
			 }
		 }
	 }
	 public void insertAtPos(int val,int pos)
	 {
		 if(pos == 1)
		 
			 insertAtFirst(val);
		
		 
		 else if(pos == size+1)
		 
			 insertAtLast(val);
		 
		 else if(pos>1 && pos<=size)
		 {
			 Node n,t;
			 n = new Node(val,null);
			 t = start;
			 for(int i=1;i<pos-1;i++)
			 {
				 t=t.getNext();
				 n.setNext(t.getNext());
				 t.setNext(n);
				 size++;
			 }
		 }
		 else
		 {
			 System.out.print("cannot insert at given position"+pos);
		 }
		
		 
			 
		 }
	 public void deleteFirst()
	 {
		 if(start == null)
		 {
			 System.out.print("List is already empty");
		 }
		 else
		 {
			 start=start.getNext();
			 size--;
		 }
	 }
	 public void deleteLast()
	 {
		 if(start == null)
		 {
			 System.out.print("List is empty");
		 }
		 else if(size == 1)
		 {
			 start =null;
			 size--;
		 }
		 else
		 {
			 Node t;
			 t=start;
			 for(int i=1;i<size-1;i++)
			 {
				 t= t.getNext();
				 t.setNext(null);
				 size--;
			 }
		 }
	 }
	 public void deleteAtPos(int pos)
	 {
		 if(start==null)
		 {
			 System.out.print("list is empty");
		 }
		 else if(pos<1 && pos>size)
		 {
			 System.out.print("invalid position");
		 }
		 else if(pos == 1)
		 {
			 deleteFirst();
		 }
		 else if(pos == size)
		 {
			 deleteLast();
		 }
		 else
		 {
			 Node t,t1;
			 t = start;
			 for(int i=1;i<size-1;i++)
			 {
				 t=t.getNext();
				 t1=t.getNext();
				 t.setNext(t1.getNext());
				 size--;
			 }
		 }
	 }
	 
			
	 }
 class TestDemo
 {
	 public static void main(String [] args)
	 {
		 LinkedList ll=new LinkedList();
		 Scanner sc=new Scanner(System.in);
                  boolean flag = true;
                  while(flag)
                  {
		 System.out.println("Enter your choice");
		 System.out.println("1. to see if list is empty");
		 System.out.println("2.to print elements of list");
		 System.out.println("3. to insert at first");
		 System.out.println("4.insert at last");
		 System.out.println("5.insert at agiven position");
		 System.out.println("6.delete at first");
		 System.out.println("delete at last");
		 System.out.println("delete at a given position");
	        
		 int i= sc.nextInt();
	
		 
		 switch(i)
		 {
		 case 1: 
		          System.out.print(ll.isEmpty());
		          break;
		 case 2:   ll.view();
		           break;
		           
		 case 3: System.out.println("Enter element you want to insert at first");
		         int f=sc.nextInt();
			      ll.insertAtFirst(f);
			   
			      break;
		 case 4: System.out.println("Enter element you want to insert at last");
         int g=sc.nextInt();
	      ll.insertAtLast(g);
	    
	      break;
		 case 5:System.out.println("Enter element you want to insert ");
		           System.out.println("Enter position of element"); 
		           int h=sc.nextInt();
		           int k=sc.nextInt();
		           ll.insertAtPos(h, k);
		         
		           break;
		 case 6:
		            ll.deleteFirst();
		            ll.view();
		            break;
		 case 7:   ll.deleteLast();
		           
		             break;
		 case 8: 
		          System.out.println("Enter position you want  to delete");
		          int l=sc.nextInt();
		          ll.deleteAtPos(l);
		         
		          break;
		     default : System.out.print("Invalid choice");
		      
		 }
		}	 
	 }
 }
