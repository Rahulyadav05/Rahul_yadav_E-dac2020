package Stack;

public class StackTest {
	
	public Node top;
	public int length;
	
	class Node
	{
		private int data;
		private Node next;
		
		public Node(int data)
		{
			this.data = data;
		}
	}
	
	public StackTest()
	{
		top = null;
		length = 0;
	}
	
	public int length()
	{
		return length;
	}
	
	public boolean isEmpty()
	{
		return length == 0;
	}
	
	public void push(int data)
	{
		Node n = new Node(data);
		n.next = top;
		top = n;
		length++;
	}
	
	public int pop()
	{
		if(isEmpty())
		{
			System.out.println("Stack is Empty: ");
		}
		
		int result = top.data;
		top = top.next;
		length--;
		return result;
	}
	
	public int peek()
	{
		if(isEmpty())
		{
			System.out.println("Stack is Empty: ");
		}
		return top.data;
	}
	
	
	  void Display() {
		  System.out.println("Printing stack elements .....");
		  for(int i = length-1; i>=0;i--){ 
			  System.out.println(top.data); 
			  top = top.next;
		  } 
		  
	  }
	 
	
	public static void main(String[] args) {

		StackTest s = new StackTest();
		s.push(10);
		s.push(15);
		s.push(20);
		s.push(30);
		s.push(40);
		s.push(50);

		s.pop();
		s.pop();
		s.Display();
		
	}

}
