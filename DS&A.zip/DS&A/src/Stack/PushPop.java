package Stack;

class Stack1
{
    int top;
    int arr[];
    int length=0;
    int n;
         Stack1(int n)
        {
          top=-1; 
          arr=new int[n];
          this.n=n;
        }
         
       void push(int val)
       {
           if(isFull())
           {
              System.out.println("Overflow");
           }
           else
           {
           top++;
           arr[top]=val;
           length++;
           System.out.println("Push Element Successfully"+val);
           }
       }
       void pop()
               
       { 
           if(isEmpty())
           {
              System.out.println("Underflow");
           }
           else
           {
           int temp=top;
           
           System.out.println("Pop Element Successfully"+temp);
           top--;
           length--;
           }
       }
       boolean isFull()
       {
           if(length>=n)
           {
              
               return true;
           }
           return false;
       }
         boolean isEmpty()
       {
           if(top<0)
           {
               return true;
           }
           return false;
       }      

         void Display() {
        	 System.out.println("Printing stack elements .....");  
        	 for(int i = top; i>=0;i--){  
        		 System.out.println(arr[i]);  
        	 }  
         }
}
          
class PushPop
{
    public static void main(String args[])
    {
     Stack1 sk=new Stack1(5);
     sk.push(10);
     sk.push(20);
     sk.push(30);
     sk.push(40);
     sk.push(50);
     sk.pop();
     sk.pop();
     sk.pop();
     sk.Display();
     
     
     
    }
}

