package Stack;

public class StackDemo1 {
	int stack[];
	int top;
	int capacity;

	public StackDemo1() {
		top = -1;
		capacity = 5;
		stack = new int[capacity];
	}

	public boolean isEmpty() {
		if (top == -1) {
			return true;
		}
		return false;
	}

	public boolean isFull() {
		if (top == capacity - 1) {
			return true;
		}
		return false;
	}

	public void push(int data) {
		if (isFull()) {
			System.out.print("Overflow condition");

		} else {
			stack[++top] = data;
		}
	}

	public int pop() {
		if (isEmpty()) {
			System.out.print("Underflow condition");
		}

		return stack[top--];

	}

	int peek() {
		return stack[top];
	}
	
	void Display() {
		System.out.println("Printing stack elements .....");  
        for(int i = top; i>=0;i--){  
            System.out.println(stack[i]);  
        }  
	}

	public static void main(String[] args) {
		StackDemo1 s = new StackDemo1();
		s.push(45);
		s.push(34);
		s.push(45);
		s.push(34);
		s.push(45);
		s.pop();
		s.Display();

	}

}