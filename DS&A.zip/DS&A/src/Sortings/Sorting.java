package Sortings;
public class Sorting {

	void bubbleSort(int arr[])
	{
		
		for(int i = 0;i<arr.length;i++)
		{
			int temp;
			for(int j = 0; j<arr.length-1-i;j++)
			{
				if(arr[j]>arr[j+1])
				{
					temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}	
	}
	
	void selectionSort(int arr[])
	{
		int min;
		int temp = 0;
		
		for(int i = 0; i<arr.length;i++)
		{
			min = i;
			for(int j = i+1; j<arr.length;j++)
			{
				if(arr[j]<arr[min])
				{
					min = j;
				}
			}
			temp = arr[i];
			arr[i] = arr[min];
			arr[min] = temp;
		}	
	}
	
	static void insertionSort(int a[])
	{
		int temp,j;
		for(int i=1;i<a.length;i++)
		{
			temp = a[i];
			j = i;
			while(j>0 && a[j-1]>temp)
			{
				a[j]=a[j-1];
				j--;
			}
			a[j]=temp;
		}
	}
	
	void display(int arr[])
	{
		for(int i = 0; i < arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}	
	}

		public static void main(String[] args) {
			
			int arr[]= {10,70,50,90,60,35};
			
			Sorting s = new Sorting();
			s.insertionSort(arr);
			s.display(arr);
			//s.bubbleSort(arr);
			
	}

}
