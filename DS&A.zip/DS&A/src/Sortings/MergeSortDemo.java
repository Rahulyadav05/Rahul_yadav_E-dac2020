package Sortings;

public class MergeSortDemo {
    int []arr;
    int []tempMergearr;
    int length;
	public static void main(String[] args) {
		int inputarr[] = {10,20,30,40,11,21,31,41};
		MergeSort1 ms=new MergeSort1();
		//ms.sort(inputarr);
          for(int i: inputarr)
          {
        	  System.out.print(i+" ");
          }
	}
	  public void sort(int inputarr[])
	  {
		  this.arr=inputarr;
		  this.length=inputarr.length;
		  this.tempMergearr=new int[length];
		    divideArray(0,length-1);
		  
	  }
	  public void divideArray(int lowerindex,int higherindex)
	  {
		  if(lowerindex<higherindex)
		  {
			  int middle=lowerindex+(higherindex-lowerindex)/2;
			  divideArray(lowerindex,middle);
			  divideArray(middle+1,higherindex);
			  MergeArray(lowerindex,middle,higherindex);
		  }
	  }
	  public void MergeArray(int lowerindex,int middle,int higherindex)
	  {
		  for(int i=lowerindex;i<=higherindex;i++)
		  {
			tempMergearr[i]=arr[i];
		  }
		  int i=lowerindex;
		  int j=middle+1;
		  int k=lowerindex;
		  while(i<=middle && j<=higherindex)
		  {
			  if(tempMergearr[i]<=tempMergearr[j])
			  {
				  arr[k]=tempMergearr[i];
				  i++;
			  }
			  else
			  {
				  arr[k]=tempMergearr[j];
				  j++;
			  }
			  k++;
		  }
		  while(i<=middle)
		  {
			  arr[k]=tempMergearr[i];
			  k++;
			  i++;
		  }
	  }

}