package Sortings;
import java.util.Scanner;

public class MergeSort1 {

	void Merge(int a[],int b[],int m,int n)
	{
		int i = 0,j=0,k=0;
		int c[] = new int[m+n];
		while(i<m && j<n)
		{
			if(a[i]<b[j])
			{
				c[k++]=a[i++];
			}
			else
			{
				c[k++]=b[j++];
			}
		}
		for(int p = 0; j < c.length;p++)
		{
			System.out.print(c[p]+" ");
		}	
	}
	
	public static void main(String[] args) {

		MergeSort1 ms = new MergeSort1();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter first array length: ");
		int m = sc.nextInt();
		int a[] = new int[m];
		System.out.println("enter second array length: ");
		int n = sc.nextInt();
		int b[] = new int[n];
		//int c[] = new int[m+n] ;
		System.out.println("enter values in array: ");
		for(int i = 0;i < a.length;i++)
		{
			a[i] = sc.nextInt();
		}
		System.out.println("enter values in array: ");
		for(int j = 0;j < b.length;j++)
		{
			b[j] = sc.nextInt();
		}
		
		ms.Merge(a,b,m,n);
	}

}
