package Tree;

class TreeNode//creation of node
{
	int data;
	TreeNode left;
	TreeNode right;
	
}
class BST//for functions 
{
	public TreeNode insert(TreeNode node,int val)
	{
		if(node == null)
		{
			return createNewNode(val);
		}
	
		if(val<node.data)
		{
		 node.left=insert(node.left,val);
		}
		else
		{
			node.right=insert(node.right,val);
		}
		
		return node;
	}
	public TreeNode delete(TreeNode node, int val)
	{
		if(node == null)
		{
			return null;
		}
		if(val>node.data)
		{
			node.right=delete(node.right,val);
		}
		else if(val<node.data)
		{
			node.left=delete(node.left,val);
		}
		else
		{
			if(node.left==null || node.right == null)
			{
				TreeNode temp=null;
				temp = node.left == null ? node.right:node.left;
				
			
			if(temp == null)
			{
				return null;
			}
			else
			{
				return temp;
			}
		}
		else
		{
			TreeNode successor = getsuccessor(node);
			node.data=successor.data;
			node.right=delete(node.right,node.data);
			return node;
		}
		}
		return node;
	}
			public TreeNode getsuccessor(TreeNode node)
			{
				if(node == null)
				{
					return null;
				}
				TreeNode temp=node.right;
				while(temp.left!= null)
				{
					temp=temp.left;
				}
				return temp;
			}
			
		     public int countNodes(TreeNode node)
		     {
		         if (node == null)
		             return 0;
		         else
		         {
		             int count = 1;
		             count += countNodes(node.left);
		             count += countNodes(node.right);
		             return count;
		         }
		     }
	
	public TreeNode createNewNode(int val)
	{
		TreeNode tn=new TreeNode();
		tn.data=val;
		tn.left=null;
		tn.right=null;
		return tn;
	}
	public void inorder(TreeNode node)
	{
		if(node == null)
		{
			return;
		}
	
		inorder(node.left);
		System.out.print(node.data+"->");
		inorder(node.right);
	}
	public void preorder(TreeNode node)
	{
	
		if(node == null)
		{
			return;
		}
	
		System.out.print(node.data+"-");
		preorder(node.left);
		preorder(node.right);
	}
	public void postorder(TreeNode node)
	{
		if(node == null )
		{
			return;
		}
		postorder(node.left);
		postorder(node.right);
		System.out.print(node.data+"=");
	}
	 public boolean search(TreeNode node, int val)
     {
         boolean found = false;
         while ((node != null) && !found)
         {
             int va = node.data;
             if (val < node.data)
                 node = node.left;
             else if (val > node.data)
                 node = node.right;
             else
             {
                 found = true;
                 break;
             }
             found = search(node, val);
         }
         return found;
     }
	

}


class BinarySearchTree// Driver code
{
	public static void main(String[] args)
	{
		BST a=new BST();
	 TreeNode root =null;
	root = a.insert(root, 45);
	root = a.insert(root, 34);
	root = a.insert(root, 12);
	root = a.insert(root, 13);
	root = a.insert(root, 78);

	

//a.inorder(root);
//a.preorder(root);
//a.postorder(root);
int z=a.countNodes(root);
System.out.println(z);
System.out.println(a.search(root, 12));
	//root = a.delete(root, 13);
	//root = a.delete(root, 12);*/
	}
}