package Tree;

class demo1
{
    demo1 left;
    demo1 right;
    int data;
    demo1(int data)
    {
        this.data=data;
    }
}

class lo
{
    demo1 insert(demo1 node,int data)
    {
        if(node==null)
        {
            node=new demo1(data);
            return node;
        }
        if(data<node.data)
        {
            node.left=insert(node.left,data);
        }
        else
        {
            node.right=insert(node.right,data);    
        }
        return node;
    }
    
    void inorder(demo1 node)
    {
        if(node == null)
        {
            return;
        }
        inorder(node.left);
        System.out.println(node.data);
        inorder(node.right);
    }   
     void preorder(demo1 node)
    {
        if(node == null)
        {
            return;
        }
        System.out.println(node.data);
        inorder(node.left);
        inorder(node.right);
    }  
     void postorder(demo1 node)
    {
        if(node == null)
        {
            return;
        }
        
        inorder(node.left);
        inorder(node.right);
        System.out.println(node.data);
    }  
}
class Trees
{
    static demo1 root;
    public static void main(String[] args)
    {
    
    lo obj= new lo();
    root=obj.insert(root,60);
    root=obj.insert(root,50);
    root= obj.insert(root,20);
    root= obj.insert(root,80);
    obj.postorder(root);
    }
}
