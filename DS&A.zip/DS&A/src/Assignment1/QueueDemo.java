package Assignment1;

public class QueueDemo {

	Node head;
	
	public QueueDemo()
	{
		head = null;
	}
	
	public void add_to_front(int x)
	{
		Node n = new Node(x);
		n.setnext(head);
		head = n;
	}
	
	public void print_list()
	{
		for(Node ptr = head;ptr!=null;ptr = ptr.getnext())
		{
			System.out.println(""+ptr.getvalue());
		}
	}
	
	public static void main(String[] args) {

		QueueDemo d = new QueueDemo();
		d.add_to_front(5);
		d.print_list();
		d.add_to_front(7);
		d.add_to_front(9);
		d.add_to_front(3);
		d.print_list();
		
	}

}
