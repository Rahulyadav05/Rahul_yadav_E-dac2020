package Assignment1;

public class Node {

	private int val;
	private Node next;
	public Node()
	{
		next = null;
	}
	public Node(int v)
	{
		next = null;
		val = v;
	}
	public Node getnext()
	{
		return next;
	}
	public void setnext(Node n)
	{
		next = n;
	}
	public int getvalue()
	{
		return val;
	}
	public void setvalue(int v)
	{
		val = v;
	}
}
