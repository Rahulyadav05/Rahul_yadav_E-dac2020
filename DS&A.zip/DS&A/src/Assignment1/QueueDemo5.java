package Assignment1;

class Queue5 { 
    int front=0, rear=-1;
    int size; 
    int a[];
    int counter=-1; 
    public Queue5(int n) 
    { 
        this.size =n; 
        a = new int[n];
    } 
    boolean isFull() 
    { 
       if(counter==size-1)
       {
           return true;
       }
       else
       {
           return false;
       }
    } 
  
    boolean isEmpty() 
    { 
      if(counter==-1)
      {
       return true;
      }
      else
      {
        return false;
      }
    } 
  
    void enqueue(int x) 
    { 
        if (isFull())
        {
            return; 
        }
        rear=(rear+1)% size;
        a[rear] = x; 
        counter++;
        System.out.println(x+ " enqueued to queue"); 
    } 

    int dequeue() 
    { 
        if (isEmpty()) 
            return 0; 
        int temp = a[front];
        front = (front+1) % size; 
        counter--;
        front++;
        System.out.println(temp+ " enqueued to queue");
        return temp;
     
    } 
  
     int front() 
    { 
        if (isEmpty()) 
            return 0; 
        else
          return a[front]; 
    } 
  
    int rear() 
    { 
        if (isEmpty()) 
            return 0; 
        else
        return a[rear]; 
    } 
} 

public class QueueDemo5 { 
    public static void main(String[] args) 
    { 
        Queue5 q = new Queue5(10); 
              q.dequeue();
       if(q.isFull())
       {
           System.out.println("Stack is full");
       }
      
  
    } 
} 

