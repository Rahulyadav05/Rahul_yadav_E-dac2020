package Assignment2;

import java.util.Scanner;

public class Prime {

	public static void main(String[] args) {
		System.out.println("Enter number to check");
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int temp = 0;
		for (int i = 1; i < a - 1; i++) {
			if (a % i == 0) {
				temp = temp + 1;
			}
		}
		if (temp == 1) {
			System.out.println(a + " prime");
		} else {
			System.out.println(" not prime");
		}
		sc.close();
	}

}
