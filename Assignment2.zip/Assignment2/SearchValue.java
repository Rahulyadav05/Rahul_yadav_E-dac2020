package Assignment2;

public class SearchValue {

	public static void main(String[] args) {
		int []arr= {1,5,8,9,10};
		int a=10;
		for (int i=0;i<arr.length;i++)
		{
			if (arr[i]==a)
			{
				System.out.print("integer found");
			}
			

	}

}
}