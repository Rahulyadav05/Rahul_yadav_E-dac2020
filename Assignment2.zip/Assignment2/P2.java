package Assignment2;

import java.util.Scanner;

public class P2 {

	public static void main(String[] args) {

		int rev = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int n = sc.nextInt();
		while (n != 0) {
			int lastDigit = n % 10;
			rev = (rev * 10) + lastDigit;
			n = n / 10;

		}
		System.out.println(rev);
	}

}
