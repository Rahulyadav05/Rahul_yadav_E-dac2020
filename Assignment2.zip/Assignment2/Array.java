package Assignment2;

public class Array {

	public static void main(String[] args) {
	 int a[]= {9,10,15};
	 int b[]= {3,5,6,};
	
      int c[]=new int[b.length];
   for(int i=0;i<a.length;i++)
   {
	c[i]=a[i]+b[i];
   }
	 
	 for(int j=0;j<c.length;j++)
	 {
		System.out.println(c[j]); 
		
	 }
   }
}