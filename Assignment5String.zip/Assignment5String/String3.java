package Assignment5String;

import java.util.*;

class StringQue8 {

	public static void main(String[] args) {
		String string = "Hello World";

		String reverse = new StringBuffer(string).reverse().toString();
		System.out.println("\nString before reverse: " + string);
		System.out.println("String after reverse: " + reverse);

	}
}