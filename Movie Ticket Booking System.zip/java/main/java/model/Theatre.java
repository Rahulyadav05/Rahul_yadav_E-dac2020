package main.java.model;

import java.time.LocalTime; 
import java.util.List;
import java.util.Map;
import java.util.Objects;


public class Theatre {

    public String name;

    public  String location;

    public Map<String, List<String>> movies;

    public int cost;

    public Theatre(String name, String location, Map<String, List<String>> movies, int cost) {
        this.name = name;
        this.location = location;
        this.movies = movies;
        this.cost = cost;
    }

}
