
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

import main.java.model.Theatre;


public class BookMySeatApplication {

    private static List<Theatre> theatreList = new ArrayList<>();

    private static List<String> listOfMovies = new ArrayList();
    
    static String username = "Rahul";
	static String password = "3448";

    static {
    	
    	
        String m1 = "Baaghi 3";
        String m2 = "Kabir Singh";
        String m3 = "Avengers";
        String m4 = "Dil Bechara";
        String m5 = "Tanhaji";

        listOfMovies.add(m1);
        listOfMovies.add(m2);
        listOfMovies.add(m3);
        listOfMovies.add(m4);
        listOfMovies.add(m5);


        String lt = LocalTime.of(10, 00).toString();
        String lt1 = LocalTime.of(14, 30).toString();
        String lt2 = LocalTime.of(18, 45).toString();
        String lt3 = LocalTime.of(20, 15).toString();

        Map<String, List<String>> movieMap1 = new HashMap<>();
        movieMap1.put(m1, Arrays.asList(lt, lt1, lt2));
        movieMap1.put(m3, Arrays.asList(lt, lt1));

        Map<String, List<String>> movieMap2 = new HashMap<>();
        movieMap2.put(m2, Arrays.asList(lt, lt1, lt2 ,lt3));
        movieMap2.put(m4, Arrays.asList(lt, lt2));

        Map<String, List<String>> movieMap3 = new HashMap<>();
        movieMap3.put(m5, Arrays.asList(lt1, lt2 ,lt3));
   

        Theatre t1 = new Theatre("Eternity", "Thane", movieMap1,300);
        Theatre t2 = new Theatre("Fun Fiesta", "Vasai", movieMap2,250);
        Theatre t3 = new Theatre("Plaza", "Dadar", movieMap3,300);
        Theatre t4 = new Theatre("PVR", "Andheri", movieMap2,150);
        Theatre t5 = new Theatre("Cinepolis Viviana", "Thane", movieMap1,400);
        Theatre t6 = new Theatre("INOX", "Kandivali", movieMap3,500);
        

        theatreList.add(t1);
        theatreList.add(t2);
        theatreList.add(t3);
        theatreList.add(t4);
        theatreList.add(t5);
        theatreList.add(t6);
   
        

    }

    public static void main(String[] args) {
        while(true){
            displayListOfMovies();
        }
    }

    private static void displayListOfMovies() {
        System.out.println("~~WELCOME TO BOOKMYSEAT~~");
        System.out.println("");
        System.out.println("WHICH MOVIE WOULD YOU LIKE TO WATCH ?");
        String selectedMovie = getUserInput(listOfMovies);
        displayCity(selectedMovie);
    }

    private static void displayCity(String selectedMovie) {
        System.out.println("IN WHICH CITY WOULD YOU LIKE TO WATCH "+selectedMovie.toUpperCase() +" ?");
        List<String> listOfLocations = new ArrayList<>();

        //Finds the theatres in which the movie is hosted
        for (int i = 0; i < theatreList.size(); i++) {
            Theatre t = theatreList.get(i);
            if(t.movies.containsKey(selectedMovie)){
                listOfLocations.add(t.location);
            }
        }

        String selectedCity = getUserInput(listOfLocations);
        displayTheatres(selectedCity,selectedMovie);
    }

    private static void displayTheatres(String selectedCity, String selectedMovie) {
        System.out.print("");
        //System.out.flush();
        System.out.println("IN WHICH THEATRE WOULD YOU LIKE TO WATCH "+selectedMovie.toUpperCase() +" in "+selectedCity.toUpperCase()+" ?");
        List<String> listOfTheatres= new ArrayList<>();
        for (int i = 0; i < theatreList.size(); i++) {
            Theatre t = theatreList.get(i);
            if(t.movies.containsKey(selectedMovie) && t.location.equals(selectedCity)){
                listOfTheatres.add(t.name);
            }
        }


        String selectedTheatre = getUserInput(listOfTheatres);
        System.out.println("Please select the show timings in "+selectedTheatre);

        List<String> listOfTime = null;
        int cost = 0;
        for (int i = 0; i < theatreList.size(); i++) {
            Theatre t = theatreList.get(i);
            if(t.name.equals(selectedTheatre)){
               listOfTime = t.movies.get(selectedMovie);
               cost = t.cost;
               break;
            }
        }
        
        

        Scanner sc = new Scanner(System.in);
        
        String selectedShowTime = getUserInput(listOfTime);
        
        System.out.println("Please select the row you want to watch between A to Z");
        
        String s1 = sc.nextLine();
        
        System.out.println("Please select no. of seats :  (Max : 5)");
        String seatCount = getUserInput(Arrays.asList("1","2","3","4","5"));
        int amount  = Integer.parseInt(seatCount)*cost;
        int gst = 18 * amount / 100;
        
        System.out.println("Enter the UserName");
        String u=sc.next();
        if(u.equals(username))
        {
        	
        }
        else
        {
        	System.out.println("Incorrect Username. ");
        }
        System.out.println("Enter the Password");
        String p=sc.next();
        if(p.equals(password))
        {
        	System.out.println("Login successfull. ");
        }
        else
        {
        	System.out.println("Incorrect Password. ");
        	try{
                Thread.sleep(1500);
            }catch (Exception e){

            }
        	displayListOfMovies();
        }
        
        System.out.println();
        
        System.out.println("Please pay Rs " + (amount + gst) + " to Book your Ticket ");
        
        System.out.println();
        
        System.out.println("Please enter your card number ");
        long cn = sc.nextLong();
        
        System.out.println("Please enter your 3 digit cvv number ");
        int cvv = sc.nextInt();
        
        System.out.println("Please enter the OTP  ");
        int otp = sc.nextInt();
        
        System.out.println("Payment Successfull ");
        
        try{
            Thread.sleep(3000);
        }catch (Exception e){

        }
        
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("\n");
        System.out.println("You have successfully booked the seats, Please find the Details Below: ");
        System.out.println();
        System.out.println("            " + selectedTheatre + " Cinema");
        System.out.println();
        System.out.println("Movie Name   : " + selectedMovie);
        System.out.println("Show Time    : "+ selectedShowTime+" , Show Cost : "+ cost);
        System.out.println("No. of seats : " + seatCount + "   ---> "+ s1 +"1 to " + s1 +""+seatCount);
        System.out.println("Show Charge  : Rs."+  amount) ;
        System.out.println("GST          : Rs."+ gst);
        System.out.println("Total        : Rs." + (amount + gst));
        System.out.println("Note : Please collect your ticket at the ticket counter");
        System.out.println("\n");
        System.out.println("--------------------------------------------------------------------------------");
        try{
            Thread.sleep(10000);
        }catch (Exception e){

        }
    }


    private static String getUserInput(List<String> options) {
        int retryCount = 3;
        int id = 0;
        String selectedOption = "";
        Map<Integer, String> optionMap = new HashMap<>();
        for (int i = 0; i < options.size(); i++) {
            System.out.println((i + 1) + ". " + options.get(i));
            optionMap.put(i + 1, options.get(i));
        }
        System.out.println(options.size()+1 + ". Exit ");
        optionMap.put(options.size()+1, "Exit");
        System.out.println("\n");
        while (retryCount != 0) {
            System.out.println("Please select among the options :");
            try {
                Scanner scannerIn = new Scanner(System.in);
                id = scannerIn.nextInt();
                if (optionMap.containsKey(id)) {
                    if (optionMap.get(id).equals("Exit"))
                        displayListOfMovies();
                    else{
                        selectedOption = optionMap.get(id);
                        break;
                    }
                } else
                   throw new Exception();
            } catch (Exception e) {
                --retryCount;
                if (retryCount > 0)
                    System.out.println("Incorrect Input, Retry Count Left : " + retryCount);
                else
                    displayListOfMovies();
            }
        }

        return selectedOption;

    }
}