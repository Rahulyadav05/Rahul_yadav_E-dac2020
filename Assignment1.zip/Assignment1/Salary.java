package Assignment1;

import java.util.Scanner;
public class Salary 
{
	void zag(float y)
	{
		if(y<10000)
		{
			double hra=0.10*y;
			double da=0.90*y;
			double gs=y+hra+da;
			System.out.println("your gross salary is"+" "+gs);
		}
		
		else if(y>=10000)
		{
			double hra=2000;
			double da=0.98*y;
			double gs=y+hra+da;
			System.out.println("your gross salary is"+" "+gs);
		}
	}
	
	

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your basic salary");
		float basicsalary=sc.nextFloat();
		System.out.println("your basic salary is "+" "+basicsalary);
		Salary s=new Salary();
		s.zag(basicsalary);
		sc.close();
	
	}
}