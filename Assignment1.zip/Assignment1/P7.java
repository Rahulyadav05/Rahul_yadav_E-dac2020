package Assignment1;

import java.util.Scanner;

public class P7 {


	public static void main(String[] args) {
		System.out.println("enter marks of 5 subjects");
	int sum=0;
	Scanner sc=new Scanner(System.in);
	
		for(int i=1;i<=5;i++)
		{
			int a=sc.nextInt();
			sum=sum+a;
			System.out.println("sum of marks is "+sum);
		}
		float z=sum/5;
		System.out.println("percentage of your marks is "+z+"%");

		}

}
