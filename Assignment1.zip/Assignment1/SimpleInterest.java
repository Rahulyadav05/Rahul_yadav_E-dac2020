package Assignment1;

import java.util.Scanner;

public class SimpleInterest {
public	static void si(double p,double r,double t)
	{
		double simpleinterest=(p*r*t)/100*100;
		
		System.out.println(simpleinterest);
	}

	public static void main(String[] args) 
	{  System.out.println("Enter principal");
		Scanner sc=new Scanner(System.in);
		double d=sc.nextDouble();
		System.out.println("Enter rate of interest");
		double r=sc.nextDouble();
	   System.out.println("Enter time");
		double w=sc.nextDouble();
		SimpleInterest.si(d,r,w);
        sc.close();
		
		
	}

}
