package Assignment1;

public class P2 {

	public static void main(String[] args) {

		 int rollNo=100;
		 System.out.println("roll no = "+rollNo);
	}

}
