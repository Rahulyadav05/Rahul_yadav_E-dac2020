package Assignment1;

public class P5 {

	public static void main(String[] args) {
		try {

	 System.out.print("welcome"+args[0]);
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
