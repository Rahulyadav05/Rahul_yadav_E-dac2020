package Assignment1;

import java.util.Scanner;

public class P3 {

	static void exp()
	{
		boolean x=true;
		boolean y=false;
		boolean z = (x && y || !(x||y));
		System.out.println("Value of z is "+z);

	}
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the x value :");
		int x =sc.nextInt();
		
		int y = (x*x)+(3*x)-7;
		System.out.println("Value of y is "+y);
		y =x++ + ++x;
		System.out.println("Value of x is "+x);
		System.out.println("Value of y is "+y);
        int z = x++ - --y - --x + x++;
        System.out.println("Value of x is "+x);
		System.out.println("Value of y is "+y);
		System.out.println("Value of z is "+z);
		
		exp();
	}

}
