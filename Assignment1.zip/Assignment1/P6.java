package Assignment1;

import java.util.Scanner;

public class P6 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the radius of circle :");
		double r = sc.nextDouble();
		double area = 3.14 * r * r;
		System.out.println("Area of Circle is " + area);
		double circumference = 2 * 3.14 * r;
		System.out.println("Circumference of the circle is " + circumference);
	}

}
