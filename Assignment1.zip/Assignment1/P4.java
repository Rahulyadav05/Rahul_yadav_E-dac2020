package Assignment1;

import java.util.Scanner;

public class P4 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the x value :");
		byte x = sc.nextByte();
		System.out.println("Enter the y value :");
		byte y = sc.nextByte();
		byte z = (byte) (x + y);
		System.out.println(z);

	}

}
