package Assignment1;

import java.util.Scanner;
public class Temperature {
	
	Temperature(double d)
	{
		double c=5*(d-32)/9;
		System.out.print("Temperature in celcius is"+c+" ");
	}

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter temperature in fahrenheit");
		double fah=sc.nextDouble();
		Temperature c=new Temperature(fah);
		sc.close();
	
	}

}